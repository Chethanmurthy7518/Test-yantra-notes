import { DebugElement } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { DomComponent } from './dom.component';

describe('DomComponent', () => {
  let component: DomComponent;
  let fixture: ComponentFixture<DomComponent>;
  let de:DebugElement

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DomComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DomComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    de = fixture.debugElement;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
it('should "add count"button clicked',()=>{
  const h1 = de.query(By.css('h1'));
  const btn = de.query(By.css('#addCount'));
  btn.triggerEventHandler('click',{});
  fixture.detectChanges();
  expect(component.count).toEqual(parseInt(h1.nativeElement.innerText))
})


  
});
