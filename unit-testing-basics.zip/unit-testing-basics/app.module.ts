import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DomComponent } from './dom/dom.component';
import { UserComponent } from './user/user.component';
import {HttpClientModule} from '@angular/common/http';
import { UnitTestComponent } from './unit-test/unit-test.component';
import { ChildComponent } from './child/child.component';
import { ParentComponent } from './parent/parent.component'

@NgModule({
  declarations: [
    AppComponent,
    DomComponent,
    UserComponent,
    UnitTestComponent,
    ChildComponent,
    ParentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
