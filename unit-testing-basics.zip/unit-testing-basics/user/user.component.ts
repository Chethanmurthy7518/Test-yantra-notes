import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
export class User { 
  constructor(public email: string, public password: string) {
  }
}
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  @Input() enabled:boolean;
@Output() loggedIn = new EventEmitter();

  constructor() {

   }
 

  ngOnInit(): void {
  }

  login(email, password) {
    console.log(`Login ${email} ${password}`);
    if (email && password) {
      console.log(`Emitting`);
      this.loggedIn.emit(new User(email, password));
    }
  }
}
