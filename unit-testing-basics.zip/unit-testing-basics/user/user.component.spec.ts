import { DebugElement } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { User, UserComponent } from './user.component';

describe('UserComponent', () => {
  let component: UserComponent;
  let fixture: ComponentFixture<UserComponent>;
  let email:DebugElement;
  let password:DebugElement;
  let subButton:DebugElement

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserComponent ]
    })
    .compileComponents();
   
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    email = fixture.debugElement.query(By.css('input[type=email]'));
    password = fixture.debugElement.query(By.css('input[type=password]'));
    subButton = fixture.debugElement.query(By.css('button'))
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('setting submit button disabled',()=>{
    component.enabled = false;
    fixture.detectChanges();
    expect(subButton.nativeElement.disabled).toBeTruthy()
  });
  it('it should enabled the submit button',()=>{
    component.enabled = true;
    fixture.detectChanges();
    expect(subButton.nativeElement.disabled).toBeFalsy()
  });
  it('should emit the user object',()=>{
    let user:User;
    email.nativeElement.value = "shafi.a@testyantra.in";
    password.nativeElement.value = "12345";
    component.loggedIn.subscribe((value)=>user= value);
    subButton.triggerEventHandler('click',{});
    expect(user.email).toEqual('shafi.a@testyantra.in');
    expect(user.password).toEqual('12345')
  })
});
