import { TestBed } from '@angular/core/testing';

import { Posts, PostService } from './post.service';

import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing'

describe('PostService', () => {
  let service: PostService;
  let  httpController:HttpTestingController;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports:[HttpClientTestingModule]
    });
    service = TestBed.inject(PostService);
    httpController = TestBed.inject(HttpTestingController)
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('should get the post from api',()=>{
    let posts:Posts[] = [
      {
        "userId": 1,
        "id": 1,
        "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
        "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
      },
      {
        "userId": 1,
        "id": 2,
        "title": "qui est esse",
        "body": "est rerum tempore vitae\nsequi sint nihil reprehenderit dolor beatae ea dolores neque\nfugiat blanditiis voluptate porro vel nihil molestiae ut reiciendis\nqui aperiam non debitis possimus qui neque nisi nulla"
      },
    ]

    service.getPosts().subscribe((res)=>{
      expect(posts).toEqual(res)
    });

    const req = httpController.expectOne('https://jsonplaceholder.typicode.com/posts');
    expect(req.cancelled).toBeFalsy();
    expect(req.request.responseType).toEqual('json');
  })
  it('should add the post from api',()=>{
    let posts:Posts =   {
        "userId": 1,
        "id": 1,
        "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
        "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
      }
      
    service.addPost(posts).subscribe((res)=>{
      expect(posts).toEqual(res)
    });

    const req = httpController.expectOne('https://jsonplaceholder.typicode.com/posts');
    expect(req.cancelled).toBeFalsy();
    expect(req.request.responseType).toEqual('json');
  })
});
