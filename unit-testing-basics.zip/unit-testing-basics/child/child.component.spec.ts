import { DebugElement } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { User } from '../user/user.component';

import { ChildComponent } from './child.component';

describe('ChildComponent', () => {
  let component: ChildComponent;
  let fixture: ComponentFixture<ChildComponent>;
  let email:DebugElement;
  let password:DebugElement;
  let submitBtn:DebugElement

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChildComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChildComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    email = fixture.debugElement.query(By.css('input[type=email]'));
    password = fixture.debugElement.query(By.css('input[type=password]'));
    submitBtn = fixture.debugElement.query(By.css('#submit'))

  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('it should disbale form',()=>{
    component.enabled = true;
    expect(component.enabled).toBeTruthy()
  })

  it('it should enable form',()=>{
    component.enabled = false;

    expect(component.enabled).toBeFalsy()
  });
it('passing login component to parent component',()=>{
  email.nativeElement.value = "abc@gmail.com";
  password.nativeElement.value = "abc";

  let user:User;
  component.loggedIn.subscribe((val)=>user=val);
  submitBtn.triggerEventHandler('click',{});
  //fixture.detectChanges()

  expect(user.email).toEqual('abc@gmail.com');
  expect(user.password).toEqual('abcd')
})
});
