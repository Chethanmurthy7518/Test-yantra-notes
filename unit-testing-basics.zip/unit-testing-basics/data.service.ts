import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Post } from './model/post';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private http:HttpClient) { }

  getPost(){
    return this.http.get<Post>(`${environment.baseUrl}posts`)
  }
  addPost(post){
    return this.http.post(`${environment.baseUrl}posts`,post)
  }
}
