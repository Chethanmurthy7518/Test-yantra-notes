import { TestBed } from '@angular/core/testing';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing'
import { DataService } from './data.service';
import { Post } from './model/post';
import { environment } from 'src/environments/environment';

describe('DataService', () => {
  let service: DataService;
  let httpController:HttpTestingController
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports:[HttpClientTestingModule],
      providers:[DataService]
    });
    service = TestBed.inject(DataService);
  });
beforeEach(()=>{
  service = TestBed.inject(DataService);
  httpController = TestBed.inject(HttpTestingController)
})
afterEach(()=>{
  httpController.verify()
})
  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should the http get method',()=>{
    const post:Post[] =[
      {
        "userId": 1,
        "id": 1,
        "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
        "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
      },
      {
        "userId": 1,
        "id": 2,
        "title": "qui est esse",
        "body": "est rerum tempore vitae\nsequi sint nihil reprehenderit dolor beatae ea dolores neque\nfugiat blanditiis voluptate porro vel nihil molestiae ut reiciendis\nqui aperiam non debitis possimus qui neque nisi nulla"
      },
    ]
    service.getPost().subscribe(post=>{
      expect(post).toBe(post,'should check mock data')
    });
    const req = httpController.expectOne(environment.baseUrl+"posts");
    expect(req.cancelled).toBeFalsy();
    expect(req.request.responseType).toEqual('json');
    req.flush(post);
    httpController.verify()
  })
});
