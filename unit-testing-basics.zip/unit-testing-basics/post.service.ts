import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
export interface Posts{
  
userId:number ,
id: number,
title: string,
body:string 
  
}
@Injectable({
  providedIn: 'root'
})
export class PostService {

  constructor(private http:HttpClient) { }

  getPosts(){
    return this.http.get<Posts[]>('https://jsonplaceholder.typicode.com/posts')
  }

  addPost(newPost){
    return this.http.post<Posts>('https://jsonplaceholder.typicode.com/posts',newPost)
  }
}
